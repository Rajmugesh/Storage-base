"""Data Validation Engine with Pydantic Schema Validation"""

import pandas as pd
import numpy as np
import logging
import re
from typing import Dict, List, Tuple, Any, Optional
from datetime import datetime
from pathlib import Path
from pydantic import BaseModel, ValidationError, create_model, ConfigDict
from typing import Optional as Opt

from src.schemas import get_schema_for_file_with_config, get_date_fields, get_numeric_fields, get_required_fields

logger = logging.getLogger(__name__)

# Date patterns for auto-detection
DATE_PATTERNS = [r'.*date.*', r'.*time.*', r'.*created.*', r'.*modified.*', r'.*updated.*']

# Type mapping for Pydantic
TYPE_MAP = {
    "string": str,
    "int": int,
    "float": float,
    "datetime": str,  # Store as string after conversion
    "bool": bool
}


class ValidationReport:
    """Comprehensive validation report"""
    __slots__ = ['file_name', 'original_rows', 'valid_rows', 'invalid_rows', 
                 'dropped_columns', 'empty_columns', 'duplicate_count', 
                 'processing_time', 'quality_score', 'validation_errors', 'error_details']
    
    def __init__(self, file_name: str):
        self.file_name = file_name
        self.original_rows = 0
        self.valid_rows = 0
        self.invalid_rows = 0
        self.dropped_columns = []
        self.empty_columns = []
        self.duplicate_count = 0
        self.processing_time = 0.0
        self.quality_score = 0.0
        self.validation_errors = []
        self.error_details = []  # List of (row_number, error_message) for detailed reporting
    
    def summary(self) -> str:
        """Generate summary for logging and email"""
        lines = [
            f"File: {self.file_name}",
            f"  Original rows: {self.original_rows:,}",
            f"  Valid rows: {self.valid_rows:,}",
            f"  Invalid rows: {self.invalid_rows:,}",
            f"  Duplicates removed: {self.duplicate_count:,}",
            f"  Quality score: {self.quality_score:.1%}",
            f"  Processing time: {self.processing_time:.2f}s"
        ]
        if self.dropped_columns:
            lines.append(f"  Dropped columns: {', '.join(self.dropped_columns)}")
        if self.empty_columns:
            lines.append(f"  Empty columns removed: {', '.join(self.empty_columns)}")
        if self.validation_errors:
            lines.append(f"  Sample errors: {len(self.validation_errors)} logged")
        
        # Add detailed error report for email notifications
        if self.error_details:
            lines.extend([
                "",
                "  VALIDATION ERRORS:",
                "  " + "-" * 40
            ])
            # Show first 10 errors with row numbers
            for row_num, error in self.error_details[:10]:
                lines.append(f"  Row {row_num}: {error}")
            if len(self.error_details) > 10:
                lines.append(f"  ... and {len(self.error_details) - 10} more errors")
        
        return "\n".join(lines)


class DataValidator:
    """
    Data Validation Engine with Pydantic Schema Validation
    
    Implements:
    - Pydantic schema validation for audit data
    - Data type checking and normalization
    - Validation rules for required fields
    - Data quality checks (null values, ranges)
    - Validation report generation
    - Separation of valid and invalid data
    - Detailed validation error logging
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        dq = config.get("data_quality", {})
        
        self.null_values = set(dq.get("null_values", ['', 'NULL', 'null', 'None', 'N/A', 'n/a', 'nan', 'NaN']))
        self.numeric_fill = dq.get("numeric_fill_value", 0)
        self.date_format = dq.get("date_format", "%Y-%m-%d %H:%M:%S")
        self.duplicate_strategy = dq.get("duplicate_strategy", "keep_first")
        self.batch_size = config.get("processing", {}).get("batch_size", 10000)
        
        self.invalid_path = Path(config["paths"]["invalid"])
        self.invalid_path.mkdir(exist_ok=True)
        
        # Cache for dynamic Pydantic models
        self._model_cache = {}

    def validate_and_clean(self, files: Dict[str, pd.DataFrame]) -> Tuple[Dict[str, pd.DataFrame], Dict[str, pd.DataFrame], List[ValidationReport]]:
        """
        Validate and clean all files.
        Returns: (valid_files, invalid_files, reports)
        """
        valid_files = {}
        invalid_files = {}
        reports = []
        
        for filename, df in files.items():
            start = datetime.now()
            report = ValidationReport(filename)
            report.original_rows = len(df)
            
            logger.info(f"Validating {filename} ({len(df):,} rows)")
            
            # Step 1: Pre-cleaning (drop id, empty columns, duplicates)
            df = self._pre_clean(df, report)
            
            # Step 2: Pydantic schema validation
            valid_df, invalid_df, errors, detailed_errors = self._validate_with_pydantic(df, filename)
            
            # Step 3: Post-cleaning (date conversion, missing value handling)
            valid_df = self._post_clean(valid_df, filename)
            
            report.valid_rows = len(valid_df)
            report.invalid_rows = len(invalid_df)
            report.validation_errors = errors[:100]  # Keep first 100 errors
            report.error_details = detailed_errors  # Store detailed errors for reporting
            report.quality_score = report.valid_rows / report.original_rows if report.original_rows > 0 else 0
            report.processing_time = (datetime.now() - start).total_seconds()
            
            valid_files[filename] = valid_df
            
            # Save invalid rows if any
            if len(invalid_df) > 0:
                invalid_files[filename] = invalid_df
                self._save_invalid_data(invalid_df, errors, filename, detailed_errors)
            
            reports.append(report)
            logger.info(report.summary())
        
        return valid_files, invalid_files, reports

    def _pre_clean(self, df: pd.DataFrame, report: ValidationReport) -> pd.DataFrame:
        """Pre-validation cleaning: drop id, empty columns, duplicates"""
        
        # Drop 'id' column
        if 'id' in df.columns:
            df = df.drop(columns=['id'])
            report.dropped_columns.append('id')
        
        # Drop completely null columns
        null_mask = df.isna() | df.isin(self.null_values)
        empty_cols = df.columns[null_mask.all()].tolist()
        if empty_cols:
            df = df.drop(columns=empty_cols)
            report.empty_columns = empty_cols
            logger.info(f"Removed empty columns: {empty_cols}")
        
        # Remove duplicates
        before = len(df)
        keep = 'first' if self.duplicate_strategy == 'keep_first' else 'last'
        df = df.drop_duplicates(keep=keep)
        report.duplicate_count = before - len(df)
        if report.duplicate_count > 0:
            logger.info(f"Removed {report.duplicate_count:,} duplicate rows")
        
        return df

    def _validate_with_pydantic(self, df: pd.DataFrame, filename: str) -> Tuple[pd.DataFrame, pd.DataFrame, List[Dict], List[Tuple]]:
        """
        Validate data using Pydantic schemas.
        Uses optimized hybrid approach: sample validation + vectorized checks.
        """
        schema = get_schema_for_file_with_config(filename, self.config)
        required_fields = get_required_fields(filename, self.config)
        
        # Reject files that don't match any known schema
        if schema is None:
            logger.error(f"Unknown file type: {filename} - No matching schema found")
            error_msg = f"File '{filename}' does not match any known schema pattern"
            errors = [{"row": "all", "errors": error_msg}]
            detailed_errors = [(1, error_msg)]
            # Return all rows as invalid
            return pd.DataFrame(), df.copy(), errors, detailed_errors
        
        # Build dynamic Pydantic model for schema validation
        model = self._build_pydantic_model(filename, df.columns.tolist(), schema)
        
        errors = []
        invalid_mask = pd.Series(False, index=df.index)
        detailed_errors = []  # For saving to CSV: (row_number, error_message)
        
        # Step 1: Validate required fields (vectorized)
        for field in required_fields:
            if field in df.columns:
                # Check for null/empty values in required fields
                null_mask = df[field].isna() | df[field].isin(self.null_values)
                if null_mask.any():
                    invalid_indices = df.index[null_mask].tolist()
                    for idx in invalid_indices:
                        error_msg = f"Required field '{field}' is null"
                        errors.append({"row": idx, "errors": error_msg})
                        detailed_errors.append((int(idx) + 1, error_msg))  # 1-based row numbers for user
                    invalid_mask |= null_mask
        
        # Step 2: Sample-based Pydantic validation (validate first 100 rows for schema)
        sample_size = min(100, len(df))
        sample_df = df.head(sample_size)
        
        schema_validation_failures = 0
        for idx, row in sample_df.iterrows():
            record = self._normalize_record(row.to_dict())
            try:
                model(**record)
            except ValidationError as e:
                schema_validation_failures += 1
                # Log validation errors for debugging but don't fail the entire file
                for error in e.errors():
                    error_msg = f"Data validation issue: {error.get('msg', 'Unknown error')} in column {error.get('loc', ['unknown'])[0] if error.get('loc') else 'unknown'}"
                    logger.debug(f"Validation warning at row {idx}: {error_msg}")
        
        # If too many schema validation failures, reject the entire file (production safety)
        # Only reject if failures are due to serious data issues, not column mismatches
        if schema_validation_failures > sample_size * 0.8:  # Increased threshold to 80% for robustness
            error_msg = f"Data quality validation failed: {schema_validation_failures}/{sample_size} sample rows contain invalid data"
            logger.error(error_msg)
            errors.append({"row": "all", "errors": error_msg})
            detailed_errors.append((1, error_msg))
            invalid_mask = pd.Series(True, index=df.index)
        elif schema_validation_failures > 0:
            logger.warning(f"Schema validation warnings: {schema_validation_failures}/{sample_size} rows have minor validation issues but will be processed")
        
        # Step 3: Data quality checks (vectorized)
        # Check for completely empty rows
        empty_row_mask = df.isna().all(axis=1)
        if empty_row_mask.any():
            invalid_mask |= empty_row_mask
            empty_indices = df.index[empty_row_mask].tolist()
            for idx in empty_indices:
                error_msg = "Row is completely empty"
                detailed_errors.append((int(idx) + 1, error_msg))
            errors.append({"row": "multiple", "errors": f"{empty_row_mask.sum()} empty rows detected"})
        
        # Split dataframe
        valid_df = df[~invalid_mask].copy()
        invalid_df = df[invalid_mask].copy()
        
        if len(invalid_df) > 0:
            logger.warning(f"Validation: {len(invalid_df)} rows failed validation")
        
        return valid_df, invalid_df, errors, detailed_errors

    def _build_pydantic_model(self, filename: str, columns: List[str], schema: Optional[Dict]) -> type:
        """Build dynamic Pydantic model for validation"""
        cache_key = f"{filename}_{hash(tuple(columns))}"
        
        if cache_key in self._model_cache:
            return self._model_cache[cache_key]
        
        fields = {}
        
        if schema and "columns" in schema:
            # Check for unknown columns in the data
            schema_columns = set(schema["columns"].keys())
            data_columns = set(columns)
            unknown_columns = data_columns - schema_columns
            
            if unknown_columns:
                logger.info(f"File {filename} contains additional columns: {unknown_columns} (will be processed as optional text)")
                # Additional columns are allowed and processed as optional strings
            
            # Use schema-defined types with case-insensitive matching
            schema_columns_lower = {k.lower(): (k, v) for k, v in schema["columns"].items()}
            
            for col in columns:
                col_lower = col.lower()
                if col_lower in schema_columns_lower:
                    original_col_name, col_def = schema_columns_lower[col_lower]
                    py_type = TYPE_MAP.get(col_def.get("type", "string"), str)
                    if col_def.get("nullable", True):
                        fields[col] = (Opt[py_type], None)
                    else:
                        fields[col] = (py_type, ...)
                else:
                    # Unknown columns are allowed as optional strings
                    fields[col] = (Opt[str], None)
        else:
            # Default: all optional strings
            for col in columns:
                fields[col] = (Opt[str], None)
        
        model = create_model(
            f"{filename.replace('.', '_')}_Schema",
            __config__=ConfigDict(str_strip_whitespace=True, extra='ignore'),
            **fields
        )
        
        self._model_cache[cache_key] = model
        return model

    def _normalize_record(self, record: Dict) -> Dict:
        """Normalize record values before validation"""
        for key, value in record.items():
            # Handle null-like values
            if pd.isna(value) or value in self.null_values:
                record[key] = None
            elif isinstance(value, str):
                value = value.strip()
                if value in self.null_values:
                    record[key] = None
                else:
                    record[key] = value
        return record

    def _post_clean(self, df: pd.DataFrame, filename: str) -> pd.DataFrame:
        """Post-validation cleaning: date conversion, missing value handling"""
        if df.empty:
            return df
        
        # Get schema info
        date_fields = get_date_fields(filename, self.config)
        numeric_fields = get_numeric_fields(filename, self.config)
        
        # Convert date columns
        df = self._convert_dates(df, date_fields)
        
        # Handle missing values
        df = self._handle_missing_values(df, numeric_fields)
        
        # Standardize text fields (trim whitespace)
        df = self._standardize_text(df)
        
        return df

    def _convert_dates(self, df: pd.DataFrame, schema_date_fields: List[str]) -> pd.DataFrame:
        """Normalize date formats to standard format"""
        for col in df.columns:
            # Check if column is in schema date fields or matches date pattern
            is_date = col in schema_date_fields or any(re.match(p, col.lower()) for p in DATE_PATTERNS)
            
            if is_date:
                try:
                    df[col] = pd.to_datetime(df[col], errors='coerce', format='mixed')
                    df[col] = df[col].dt.strftime(self.date_format)
                    df[col] = df[col].replace('NaT', np.nan)
                except Exception:
                    pass
        return df

    def _handle_missing_values(self, df: pd.DataFrame, schema_numeric_fields: List[str]) -> pd.DataFrame:
        """Handle missing values: 0 for numeric, null for categorical"""
        for col in df.columns:
            # Replace null-like strings
            df[col] = df[col].replace(list(self.null_values), np.nan)
            
            # Check if numeric (from schema or auto-detect)
            is_numeric = col in schema_numeric_fields
            
            if not is_numeric:
                # Auto-detect numeric columns
                numeric = pd.to_numeric(df[col], errors='coerce')
                non_null = df[col].notna().sum()
                numeric_count = numeric.notna().sum()
                is_numeric = non_null > 0 and (numeric_count / non_null) > 0.5
            
            if is_numeric:
                # Numeric: fill with 0
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(self.numeric_fill)
            else:
                # Categorical: keep null, clean strings
                if df[col].dtype == 'object':
                    df[col] = df[col].astype(str).str.strip()
                    df[col] = df[col].replace(['nan', 'None', ''], np.nan)
        
        return df

    def _standardize_text(self, df: pd.DataFrame) -> pd.DataFrame:
        """Standardize text fields: trim whitespace"""
        for col in df.select_dtypes(include=['object']).columns:
            df[col] = df[col].astype(str).str.strip()
            df[col] = df[col].replace(['nan', 'None', ''], np.nan)
        return df

    def _save_invalid_data(self, invalid_df: pd.DataFrame, errors: List[Dict], filename: str, detailed_errors: List[Tuple]):
        """Save invalid data and error details"""
        # Save invalid rows
        invalid_file = self.invalid_path / f"{Path(filename).stem}_invalid.csv"
        invalid_df.to_csv(invalid_file, index=False)
        logger.info(f"Saved {len(invalid_df)} invalid rows to {invalid_file}")
        
        # Save detailed error information with row numbers
        if detailed_errors:
            error_file = self.invalid_path / f"{Path(filename).stem}_errors.csv"
            error_df = pd.DataFrame(detailed_errors, columns=['Row_Number', 'Error_Message'])
            error_df.to_csv(error_file, index=False)
            logger.info(f"Saved {len(detailed_errors)} validation errors to {error_file}")
        
        # Also save legacy error format for compatibility
        if errors:
            legacy_error_file = self.invalid_path / f"{Path(filename).stem}_legacy_errors.csv"
            pd.DataFrame(errors).to_csv(legacy_error_file, index=False)
