"""Production Pipeline Orchestrator with Pydantic Validation"""

import logging
from datetime import datetime
from typing import Dict, Any, List

from src.file_handler import FileHandler
from src.validation_engine import DataValidator, ValidationReport
from ingestion.cleaners import DataCleaner
from src.notifier import Notifier
from src.db import get_engine
from src.schemas import get_schema_for_file
from src.staging_writer import (
    ensure_staging_tables,
    resolve_product_code,
    resolve_staging_table,
    create_ingestion_batch,
    finalize_ingestion_batch,
    write_df_to_staging,
)

logger = logging.getLogger(__name__)


class PipelineOrchestrator:
    """
    Production Data Pipeline Orchestrator
    
    Coordinates:
    - File loading (CSV/Excel with incremental processing)
    - Pydantic schema validation
    - Data cleaning and transformation
    - Output with timestamps (no overwrite)
    - Email notifications with detailed reports
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.file_handler = FileHandler(config)
        self.validator = DataValidator(config)
        self.cleaner = DataCleaner(config)
        self.notifier = Notifier(config)

    def run(self) -> Dict[str, Any]:
        """Execute pipeline - processes only new/modified files"""
        start_time = datetime.now()
        
        stats = {
            'status': 'RUNNING',
            'files_processed': 0,
            'total_input_rows': 0,
            'total_valid_rows': 0,
            'total_invalid_rows': 0,
            'total_output_rows': 0,
            'processing_time': 0,
            'retention_rate': 0,
            'errors': []
        }
        
        try:
            logger.info("=" * 60)
            logger.info("DATA INGESTION PIPELINE STARTED")
            logger.info("=" * 60)
            
            # Step 1: Load new/modified files (CSV/Excel)
            logger.info("Step 1: Loading files...")
            files, new_files = self.file_handler.load_files()
            
            if not files:
                logger.info("No new files to process")
                stats['status'] = 'COMPLETED'
                stats['processing_time'] = (datetime.now() - start_time).total_seconds()
                return stats
            
            stats['files_processed'] = len(files)
            stats['total_input_rows'] = sum(len(df) for df in files.values())
            
            # Step 2: Pydantic Schema Validation
            logger.info("Step 2: Pydantic schema validation...")
            valid_files, invalid_files, validation_reports = self.validator.validate_and_clean(files)
            
            stats['total_valid_rows'] = sum(len(df) for df in valid_files.values())
            stats['total_invalid_rows'] = sum(len(df) for df in invalid_files.values())
            
            # Step 3: Data Cleaning Pipeline
            logger.info("Step 3: Data cleaning pipeline...")
            cleaned_files, cleaning_reports = self.cleaner.process_files(valid_files)
            
            stats['total_output_rows'] = sum(len(df) for df in cleaned_files.values())

            # Step 3b: Save cleaned output to PostgreSQL staging tables (optional)
            db_cfg = self.config.get("database", {})
            if db_cfg.get("enabled", False):
                engine = get_engine(self.config)
                ensure_staging_tables(engine, self.config)
                staging_schema = db_cfg.get("schema", "staging")
                db_batch_size = db_cfg.get("batch_size", 10000)
                bootstrap_ddl = db_cfg.get("bootstrap_ddl", False)
                db_use_copy = bool(db_cfg.get("use_copy", True))
                db_delete_existing_signature = bool(db_cfg.get("delete_existing_signature", True))
                db_truncate_before_load = bool(db_cfg.get("truncate_before_load", False))
                db_dedupe_before_insert = bool(db_cfg.get("dedupe_before_insert", True))

                for filename, df in cleaned_files.items():
                    schema_info = get_schema_for_file(filename, self.config)
                    if not schema_info:
                        logger.warning(f"Skipping DB load (unknown schema): {filename}")
                        continue

                    staging_cfg = self.config.get("staging", {})
                    dedupe_cfg = staging_cfg.get("dedupe", {}) if isinstance(staging_cfg, dict) else {}
                    dedupe_subset = dedupe_cfg.get(schema_info["table_name"], []) if isinstance(dedupe_cfg, dict) else []

                    product_code = resolve_product_code(filename, self.config)
                    target_table = resolve_staging_table(schema_info["table_name"], self.config)
                    signature = self.file_handler.get_file_signature(filename)
                    batch_id = create_ingestion_batch(
                        engine=engine,
                        schema=staging_schema,
                        product_code=product_code,
                        filename=filename,
                        signature=signature,
                        input_rows=len(df),
                        bootstrap=bootstrap_ddl,
                    )

                    try:
                        inserted = write_df_to_staging(
                            df,
                            engine=engine,
                            schema=staging_schema,
                            table_name=target_table,
                            product_code=product_code,
                            batch_id=batch_id,
                            source_filename=filename,
                            source_signature=signature,
                            batch_size=db_batch_size,
                            use_copy=db_use_copy,
                            delete_existing_signature=db_delete_existing_signature,
                            truncate_before_load=db_truncate_before_load,
                            dedupe_before_insert=db_dedupe_before_insert,
                            dedupe_subset=dedupe_subset,
                        )
                        finalize_ingestion_batch(engine, schema=staging_schema, batch_id=batch_id, inserted_rows=inserted, status="COMPLETED")
                        logger.info(f"DB staging load OK: {staging_schema}.{target_table} rows={inserted:,} file={filename}")
                    except Exception as e:
                        err_msg = (
                            f"[DB_LOAD] file={filename} table={staging_schema}.{target_table} "
                            f"batch_id={batch_id} :: {type(e).__name__}: {e}"
                        )
                        finalize_ingestion_batch(
                                engine,
                                schema=staging_schema,
                                batch_id=batch_id,
                                inserted_rows=0,
                                status="FAILED",
                                error_message=err_msg,
                            )
                        logger.exception(err_msg)
                        raise

            # # Step 4: Save with timestamps (no overwrite)
            # logger.info("Step 4: Saving output files...")
            # for filename, df in cleaned_files.items():
            #     signature = self.file_handler.get_file_signature(filename)
            #     output_name = self.file_handler.save_with_timestamp(df, filename, signature)
            #     logger.info(f"Saved: {filename} -> {output_name} ({len(df):,} rows)")


            # Step 4: Save with timestamps (no overwrite)
            db_cfg = self.config.get("database", {})
            if db_cfg.get("enabled", False):
                logger.info("Step 4: Skipping output file save (DB enabled)")
            else:
                logger.info("Step 4: Saving output files...")
                for filename, df in cleaned_files.items():
                    signature = self.file_handler.get_file_signature(filename)
                    output_name = self.file_handler.save_with_timestamp(df, filename, signature)
                    logger.info(f"Saved: {filename} -> {output_name} ({len(df):,} rows)")
            
            # Calculate final stats
            processing_time = (datetime.now() - start_time).total_seconds()
            stats['status'] = 'COMPLETED'
            stats['processing_time'] = processing_time
            stats['retention_rate'] = stats['total_output_rows'] / stats['total_input_rows'] if stats['total_input_rows'] > 0 else 0
            
            # Log final summary
            self._log_summary(stats, validation_reports)
            
            # Step 5: Send email report
            logger.info("Step 5: Sending notification...")
            self.notifier.send_report(validation_reports, stats)
            
            return stats
            
        except Exception as e:
            logger.error(f"Pipeline failed: {e}", exc_info=True)
            stats['status'] = 'FAILED'
            stats['errors'].append(f"{type(e).__name__}: {e}")
            stats['processing_time'] = (datetime.now() - start_time).total_seconds()
            return stats

    def _log_summary(self, stats: Dict, reports: List[ValidationReport]):
        """Log detailed summary to console and log file"""
        logger.info("")
        logger.info("=" * 60)
        logger.info("PIPELINE COMPLETED SUCCESSFULLY")
        logger.info("=" * 60)
        logger.info(f"Processing Time: {stats['processing_time']:.2f} seconds")
        logger.info(f"Files Processed: {stats['files_processed']}")
        logger.info(f"Total Input Rows: {stats['total_input_rows']:,}")
        logger.info(f"Valid Rows: {stats['total_valid_rows']:,}")
        logger.info(f"Invalid Rows: {stats['total_invalid_rows']:,}")
        logger.info(f"Output Rows: {stats['total_output_rows']:,}")
        logger.info(f"Data Retention: {stats['retention_rate']:.1%}")
        logger.info("")
        logger.info("VALIDATION REPORTS:")
        logger.info("-" * 40)
        
        for report in reports:
            logger.info(report.summary())
            logger.info("")
        
        logger.info("=" * 60)
