from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

def get_engine(config) -> Engine:
    db = config.get("database", {})
    url = db.get("url")
    if not url:
        raise ValueError("Missing database.url in config")
    return create_engine(url, future=True, pool_pre_ping=True)