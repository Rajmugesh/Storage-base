import pandas as pd
import logging
import json
from typing import Dict, Optional, List, Tuple
from pathlib import Path
from datetime import datetime

logger = logging.getLogger(__name__)

class FileHandler:
    """Production file handler with CSV/Excel support and incremental processing"""
    
    def __init__(self, config: Dict):
        self.config = config
        self.raw_path = Path(config["paths"]["raw"])
        self.output_path = Path(config["paths"]["output"])
        self.logs_path = Path(config["paths"]["logs"])
        self.tracker_path = Path(config["paths"].get("processed_tracker", "./logs/processed_files.json"))
        
        # Create directories
        self.output_path.mkdir(parents=True, exist_ok=True)
        self.logs_path.mkdir(parents=True, exist_ok=True)
        
        # Supported formats from config
        self.supported_formats = config.get("processing", {}).get("supported_formats", [".csv", ".xlsx", ".xls"])
        self.null_values = config.get("data_quality", {}).get("null_values", [])
        
        # Load processed files tracker
        self.processed_files = self._load_tracker()

    def _load_tracker(self) -> Dict:
        """Load processed files tracker"""
        try:
            if self.tracker_path.exists():
                with open(self.tracker_path, 'r') as f:
                    return json.load(f)
        except Exception as e:
            logger.warning(f"Could not load tracker: {e}")
        return {}

    def _save_tracker(self):
        """Save processed files tracker"""
        try:
            with open(self.tracker_path, 'w') as f:
                json.dump(self.processed_files, f, indent=2)
        except Exception as e:
            logger.warning(f"Could not save tracker: {e}")

    def _get_file_signature(self, file_path: Path) -> str:
        """Get unique signature for file based on modification time and size"""
        stat = file_path.stat()
        return f"{stat.st_mtime}_{stat.st_size}"

    def load_files(self) -> Tuple[Dict[str, pd.DataFrame], List[str]]:
        """Load new/modified files (CSV and Excel) from raw directory"""
        data = {}
        new_files = []
        
        # Find all supported files
        all_files = []
        for fmt in self.supported_formats:
            all_files.extend(self.raw_path.glob(f"*{fmt}"))
        
        if not all_files:
            logger.warning(f"No files found in {self.raw_path}")
            return data, new_files
        
        logger.info(f"Found {len(all_files)} files in raw directory")
        
        for file_path in all_files:
            filename = file_path.name
            signature = self._get_file_signature(file_path)
            
            # Check if file was already processed with same signature
            if filename in self.processed_files:
                if self.processed_files[filename].get("signature") == signature:
                    logger.info(f"Skipping {filename} (already processed)")
                    continue
                else:
                    logger.info(f"Re-processing {filename} (file modified)")
            
            # Load file
            df = self._load_file(file_path)
            if df is not None:
                data[filename] = df
                new_files.append(filename)
                logger.info(f"Loaded {filename}: {len(df):,} rows")
        
        if not new_files:
            logger.info("No new files to process")
        else:
            logger.info(f"Loaded {len(new_files)} new/modified files")
        
        return data, new_files

    def _load_file(self, file_path: Path) -> Optional[pd.DataFrame]:
        """Load CSV or Excel file"""
        try:
            suffix = file_path.suffix.lower()
            
            if suffix == '.csv':
                df = pd.read_csv(
                    file_path,
                    low_memory=False,
                    dtype=str,
                    na_values=self.null_values,
                    keep_default_na=False,
                    encoding='utf-8',
                    on_bad_lines='warn'
                )
            elif suffix in ['.xlsx', '.xls']:
                df = pd.read_excel(
                    file_path,
                    dtype=str,
                    na_values=self.null_values,
                    keep_default_na=False
                )
            else:
                logger.warning(f"Unsupported format: {suffix}")
                return None
            
            if df.empty:
                logger.warning(f"{file_path.name} is empty")
                return None
            
            return df
            
        except UnicodeDecodeError:
            if file_path.suffix.lower() == ".csv":
                try:
                    return pd.read_csv(file_path, dtype=str, encoding="latin-1", on_bad_lines="warn")
                except Exception as e2:
                    logger.exception(
                        f"[FILE_LOAD] Failed to load CSV with utf-8 and latin-1: {file_path.name} :: "
                        f"{type(e2).__name__}: {e2}"
                    )
                    return None
 
            logger.exception(
                f"[FILE_LOAD] Unicode decode error: {file_path.name} :: {type(e).__name__}: {e}"
            )
        return None



            # Retry with latin-1 for CSV
        #     if file_path.suffix.lower() == '.csv':
        #         try:
        #             return pd.read_csv(file_path, dtype=str, encoding='latin-1', on_bad_lines='warn')
        #         except Exception:
        #             pass
        #     logger.error(f"Failed to load {file_path.name}")
        #     return None
        # except Exception as e:
        #     logger.error(f"Error loading {file_path.name}: {e}")
        #     return None

    def save_with_timestamp(self, df: pd.DataFrame, original_filename: str, signature: str) -> str:
        """Save file with timestamp, don't overwrite existing outputs"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Get base name without extension
        base_name = Path(original_filename).stem
        output_filename = f"{base_name}_{timestamp}.csv"
        output_path = self.output_path / output_filename
        
        # Save as CSV
        df.to_csv(output_path, index=False, na_rep='')
        
        # Update tracker
        self.processed_files[original_filename] = {
            "signature": signature,
            "processed_at": timestamp,
            "output_file": output_filename,
            "rows": len(df)
        }
        self._save_tracker()
        
        return output_filename

    def get_file_signature(self, filename: str) -> str:
        """Get signature for a file in raw directory"""
        file_path = self.raw_path / filename
        if file_path.exists():
            return self._get_file_signature(file_path)
        return ""
