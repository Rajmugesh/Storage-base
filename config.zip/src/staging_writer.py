from __future__ import annotations

import io
import csv
import uuid
from pathlib import Path
from typing import Any

import pandas as pd
from sqlalchemy import text
from sqlalchemy.engine import Engine

from src.schemas import SCHEMA_REGISTRY


def _quote_ident(ident: str) -> str:
    return '"' + ident.replace('"', '""') + '"'


def _pg_type_from_schema_type(schema_type: str) -> str:
    t = (schema_type or "string").lower()
    if t == "int":
        return "bigint"
    if t == "float":
        return "double precision"
    if t == "bool":
        return "boolean"
    if t == "datetime":
        return "timestamptz"
    return "text"


def _read_csv_header(raw_dir: str | Path, filename: str) -> list[str]:
    p = Path(raw_dir) / filename
    with p.open("r", encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        header = next(reader)
    # strip optional surrounding quotes/spaces
    return [h.strip().strip('"').strip() for h in header]


def ensure_staging_tables(engine: Engine, config: dict[str, Any]) -> None:
    """
    Config-driven bootstrap:
    - creates schema
    - creates ingestion_batch (already implemented)
    - creates/updates staging target tables in staging.table_map
    """
    db_cfg = config.get("database", {})
    staging_cfg = config.get("staging", {})
    schema = db_cfg.get("schema", "staging")
    bootstrap = bool(db_cfg.get("bootstrap_ddl", False))
    if not bootstrap:
        return

    table_map = staging_cfg.get("table_map", {})
    if not isinstance(table_map, dict) or not table_map:
        raise ValueError("staging.table_map missing/empty; cannot bootstrap staging tables.")

    # Controls how columns are generated
    bootstrap_cfg = staging_cfg.get("bootstrap", {})
    mode_default = bootstrap_cfg.get("mode", "from_schema_registry")  # or from_raw_header
    type_policy = bootstrap_cfg.get("type_policy", "hybrid")
    recreate_tables = bool(bootstrap_cfg.get("recreate_tables", False))
    raw_dir = bootstrap_cfg.get("raw_dir", config.get("paths", {}).get("raw", "./raw"))
    drop_id = bool(bootstrap_cfg.get("drop_id", True))
    create_missing_columns = bool(bootstrap_cfg.get("create_missing_columns", True))

    # Required audit columns (must match write_df_to_staging)
    audit_cols: list[tuple[str, str]] = [
        ("product_code", "text"),
        ("batch_id", "uuid"),
        ("source_filename", "text"),
        ("source_signature", "text"),
        ("source_row_number", "bigint"),
    ]

    with engine.begin() as conn:
        conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {_quote_ident(schema)}"))

        ensure_ingestion_batch(engine, schema, bootstrap=True)

        table_exists_sql = text(
            """
            SELECT 1
            FROM information_schema.tables
            WHERE table_schema = :schema AND table_name = :table
            """
        )

        for schema_table_name, staging_table in table_map.items():
            mode = bootstrap_cfg.get("tables", {}).get(schema_table_name, {}).get("mode", mode_default)

            schema_def = SCHEMA_REGISTRY.get(schema_table_name) or {}
            schema_cols = schema_def.get("columns", {}) if isinstance(schema_def, dict) else {}
            schema_cols_lower = {k.lower(): v for k, v in schema_cols.items()}

            if mode == "from_schema_registry":
                if not schema_def:
                    raise ValueError(f"No schema registry entry for {schema_table_name}")
                business_cols: list[tuple[str, str]] = []
                for col_name, col_def in schema_cols.items():
                    pg_t = _pg_type_from_schema_type(col_def.get("type"))
                    business_cols.append((col_name, pg_t))

            elif mode == "from_raw_header":
                filename = f"{schema_table_name}.csv"
                header_cols = _read_csv_header(raw_dir, filename)
                if drop_id:
                    header_cols = [c for c in header_cols if c.lower() != "id"]

                business_cols = []
                for c in header_cols:
                    if type_policy == "all_text":
                        business_cols.append((c, "text"))
                        continue

                    col_def = schema_cols_lower.get(c.lower())
                    if col_def:
                        business_cols.append((c, _pg_type_from_schema_type(col_def.get("type"))))
                    else:
                        business_cols.append((c, "text"))

            else:
                raise ValueError(f"Unknown staging.bootstrap.mode={mode} for {schema_table_name}")

            all_cols = audit_cols + business_cols

            exists = conn.execute(table_exists_sql, {"schema": schema, "table": staging_table}).first() is not None
            if exists and recreate_tables:
                conn.execute(text(f"DROP TABLE IF EXISTS {_quote_ident(schema)}.{_quote_ident(staging_table)}"))
                exists = False
            if not exists:
                col_ddl = ",\n  ".join(f"{_quote_ident(c)} {t}" for c, t in all_cols)
                conn.execute(
                    text(
                        f"""
                        CREATE TABLE IF NOT EXISTS {_quote_ident(schema)}.{_quote_ident(staging_table)} (
                          {col_ddl}
                        )
                        """
                    )
                )

            if create_missing_columns:
                existing = _get_table_columns(engine, schema, staging_table)
                missing = [(c, t) for (c, t) in all_cols if c not in existing]
                if missing:
                    alter_parts = ", ".join(
                        f"ADD COLUMN IF NOT EXISTS {_quote_ident(c)} {t}" for c, t in missing
                    )
                    conn.execute(
                        text(f"ALTER TABLE {_quote_ident(schema)}.{_quote_ident(staging_table)} {alter_parts}")
                    )

            _ensure_table_indexes(conn=conn, schema=schema, staging_table=staging_table, schema_table_name=schema_table_name, config=config)


def _ensure_table_indexes(*, conn, schema: str, staging_table: str, schema_table_name: str, config: dict[str, Any]) -> None:
    staging_cfg = config.get("staging", {})
    indexes_cfg = staging_cfg.get("indexes", {}) if isinstance(staging_cfg, dict) else {}
    if not isinstance(indexes_cfg, dict) or not indexes_cfg.get("enabled", False):
        return

    tables_cfg = indexes_cfg.get("tables", {})
    if not isinstance(tables_cfg, dict):
        return

    idx_list = tables_cfg.get(schema_table_name, [])
    if not isinstance(idx_list, list):
        return

    for idx in idx_list:
        if not isinstance(idx, dict):
            continue
        idx_name = idx.get("name")
        cols = idx.get("columns", [])
        unique = bool(idx.get("unique", False))

        if not idx_name or not cols or not isinstance(cols, list):
            continue

        cols_sql = ", ".join(_quote_ident(str(c)) for c in cols)
        unique_sql = "UNIQUE " if unique else ""
        conn.execute(
            text(
                f"CREATE {unique_sql}INDEX IF NOT EXISTS {_quote_ident(idx_name)} ON {_quote_ident(schema)}.{_quote_ident(staging_table)} ({cols_sql})"
            )
        )


def resolve_product_code(filename: str, config) -> str:
    products = config.get("products", {})
    default_code = products.get("default_product_code", "default")

    for rule in products.get("rules", []):
        needle = (rule.get("filename_contains") or "").lower().strip()
        if needle and needle in filename.lower():
            return rule.get("product_code") or default_code

    return default_code


def resolve_staging_table(schema_table_name: str, config) -> str:
    table_map = config.get("staging", {}).get("table_map", {})
    table = table_map.get(schema_table_name)
    if not table:
        raise ValueError(f"No staging.table_map entry for '{schema_table_name}'")
    return table


def ensure_ingestion_batch(engine: Engine, schema: str, *, bootstrap: bool) -> None:
    exists_sql = text(
        """
        SELECT 1
        FROM information_schema.tables
        WHERE table_schema = :schema AND table_name = 'ingestion_batch'
        """
    )

    with engine.begin() as conn:
        exists = conn.execute(exists_sql, {"schema": schema}).first() is not None
        if exists:
            return
        if not bootstrap:
            raise RuntimeError(
                f"Missing required table {schema}.ingestion_batch. Create it with DBA privileges or set database.bootstrap_ddl=true."
            )

        ddl_statements = [
            text(f"CREATE SCHEMA IF NOT EXISTS {_quote_ident(schema)}"),
            text(
                f"""
                CREATE TABLE IF NOT EXISTS {_quote_ident(schema)}.ingestion_batch (
                  batch_id           uuid PRIMARY KEY,
                  product_code       text NOT NULL,
                  source_filename    text NOT NULL,
                  source_signature   text,
                  started_at         timestamptz NOT NULL DEFAULT now(),
                  finished_at        timestamptz,
                  status             text NOT NULL DEFAULT 'STARTED',
                  input_rows         integer,
                  inserted_rows      integer,
                  error_message      text
                )
                """
            ),
            text(
                f"""
                CREATE INDEX IF NOT EXISTS ix_ingestion_batch_product_time
                  ON {_quote_ident(schema)}.ingestion_batch (product_code, started_at DESC)
                """
            ),
        ]

        for stmt in ddl_statements:
            conn.execute(stmt)


def create_ingestion_batch(
    *,
    engine: Engine,
    schema: str,
    product_code: str,
    filename: str,
    signature: str,
    input_rows: int,
    bootstrap: bool = False,
) -> str:
    ensure_ingestion_batch(engine, schema, bootstrap=bootstrap)
    new_batch_id = str(uuid.uuid4())
    sql = text(
        f"""
        INSERT INTO {_quote_ident(schema)}.ingestion_batch (batch_id, product_code, source_filename, source_signature, input_rows, status)
        VALUES (:batch_id, :product_code, :source_filename, :source_signature, :input_rows, 'STARTED')
        RETURNING batch_id
        """
    )
    with engine.begin() as conn:
        return str(
            conn.execute(
                sql,
                {
                    "batch_id": new_batch_id,
                    "product_code": product_code,
                    "source_filename": filename,
                    "source_signature": signature,
                    "input_rows": input_rows,
                },
            ).scalar_one()
        )


def finalize_ingestion_batch(
    engine: Engine,
    schema: str,
    batch_id: str,
    inserted_rows: int,
    status: str,
    error_message: str | None = None,
) -> None:
    sql = text(
        f"""
        UPDATE {_quote_ident(schema)}.ingestion_batch
        SET finished_at = now(),
            inserted_rows = :inserted_rows,
            status = :status,
            error_message = :error_message
        WHERE batch_id = :batch_id
        """
    )
    with engine.begin() as conn:
        conn.execute(
            sql,
            {
                "batch_id": batch_id,
                "inserted_rows": inserted_rows,
                "status": status,
                "error_message": error_message,
            },
        )


def _get_table_columns(engine: Engine, schema: str, table: str) -> set[str]:
    sql = text(
        """
        SELECT column_name
        FROM information_schema.columns
        WHERE table_schema = :schema AND table_name = :table
        """
    )
    with engine.begin() as conn:
        rows = conn.execute(sql, {"schema": schema, "table": table}).all()
    return {r[0] for r in rows}


def write_df_to_staging(
    df: pd.DataFrame,
    *,
    engine: Engine,
    schema: str,
    table_name: str,
    product_code: str,
    batch_id: str,
    source_filename: str,
    source_signature: str,
    batch_size: int = 10000,
    use_copy: bool = True,
    delete_existing_signature: bool = True,
    truncate_before_load: bool = False,
    dedupe_before_insert: bool = True,
    dedupe_subset: list[str] | None = None,
) -> int:
    if df is None or df.empty:
        return 0

    out = df.copy()

    if dedupe_before_insert:
        out = out.drop_duplicates()

    # Optional: business-key dedupe (prevents duplicates for mapping keys like EvaluationCode)
    if dedupe_subset:
        subset_cols = [c for c in dedupe_subset if c in out.columns]
        if subset_cols:
            out = out.drop_duplicates(subset=subset_cols)

    out.insert(0, "product_code", product_code)
    out.insert(1, "batch_id", batch_id)
    out.insert(2, "source_filename", source_filename)
    out.insert(3, "source_signature", source_signature)
    out.insert(4, "source_row_number", range(1, len(out) + 1))

    table_cols = _get_table_columns(engine, schema, table_name)
    if not table_cols:
        raise RuntimeError(
            f"Target table does not exist or has no visible columns: {schema}.{table_name}. "
            f"Create it (or enable database.bootstrap_ddl and configure staging.bootstrap)."
        )

    kept_cols = [c for c in out.columns if c in table_cols]
    dropped_cols = [c for c in out.columns if c not in table_cols]
    out = out[kept_cols]

    if out.empty:
        raise RuntimeError(
            f"No columns matched target table {schema}.{table_name}. "
            f"Dropped columns={dropped_cols}. Table columns={sorted(table_cols)}."
        )

    out = out.where(pd.notnull(out), None)

    if truncate_before_load:
        with engine.begin() as conn:
            conn.execute(text(f"TRUNCATE TABLE {_quote_ident(schema)}.{_quote_ident(table_name)}"))
    elif delete_existing_signature:
        with engine.begin() as conn:
            conn.execute(
                text(
                    f"""
                    DELETE FROM {_quote_ident(schema)}.{_quote_ident(table_name)}
                    WHERE product_code = :pc
                      AND source_filename = :fn
                      AND source_signature = :sig
                    """
                ),
                {"pc": product_code, "fn": source_filename, "sig": source_signature},
            )

    cols = list(out.columns)

    if use_copy:
        buf = io.StringIO()
        out.to_csv(
            buf,
            index=False,
            header=False,
            na_rep="\\N",
            quoting=csv.QUOTE_MINIMAL,
        )
        buf.seek(0)

        copy_cols = ", ".join(_quote_ident(c) for c in cols)
        copy_sql = (
            f"COPY {_quote_ident(schema)}.{_quote_ident(table_name)} ({copy_cols}) "
            f"FROM STDIN WITH (FORMAT CSV, NULL '\\N')"
        )

        raw = engine.raw_connection()
        try:
            cur = raw.cursor()
            cur.copy_expert(copy_sql, buf)
            raw.commit()
        finally:
            raw.close()

        return len(out)

    col_sql = ", ".join(_quote_ident(c) for c in cols)
    val_sql = ", ".join(f":{c}" for c in cols)
    insert_sql = text(
        f"INSERT INTO {_quote_ident(schema)}.{_quote_ident(table_name)} ({col_sql}) VALUES ({val_sql})"
    )

    records = out.to_dict(orient="records")
    inserted_rows = 0
    with engine.begin() as conn:
        for i in range(0, len(records), batch_size):
            chunk = records[i : i + batch_size]
            conn.execute(insert_sql, chunk)
            inserted_rows += len(chunk)

    return inserted_rows