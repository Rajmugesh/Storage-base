"""Pydantic Schema Definitions for Data Validation"""

from pydantic import BaseModel, Field, field_validator, ConfigDict
from typing import Optional, Any, Dict, List
from datetime import datetime
import re


# Type mapping for dynamic schema creation
TYPE_MAP = {
    "string": str,
    "int": int,
    "float": float,
    "datetime": datetime,
    "bool": bool
}


class BaseAuditSchema(BaseModel):
    """Base schema with common audit fields"""
    model_config = ConfigDict(str_strip_whitespace=True, extra='ignore')
    
    @field_validator('*', mode='before')
    @classmethod
    def handle_empty_strings(cls, v):
        """Convert empty strings and null-like values to None"""
        if isinstance(v, str):
            v = v.strip()
            if v in ('', 'NULL', 'null', 'None', 'N/A', 'n/a', 'nan', 'NaN'):
                return None
        return v


# Schema definitions for each table type
SCHEMA_REGISTRY: Dict[str, Dict[str, Any]] = {
    "tbl_DW_EvaluationParameter": {
        "columns": {
            "ParameterEvaluationCode": {"type": "string", "required": True},
            "ParameterMappingCode": {"type": "string", "required": False, "nullable": True},
            "ParameterFormCode": {"type": "string", "required": False, "nullable": True},
            "ParameterProcessCode": {"type": "string", "required": False, "nullable": True},
            "ParameterType": {"type": "string", "required": False, "nullable": True},
            "ParameterStatus": {"type": "string", "required": False, "nullable": True},
            "ParameterParamCode": {"type": "string", "required": False, "nullable": True},
            "ParameterParentCode": {"type": "string", "required": False, "nullable": True},
            "ParameterParentName": {"type": "string", "required": False, "nullable": True},
            "ParameterParamName": {"type": "string", "required": False, "nullable": True},
            "ParameterOrderID": {"type": "int", "required": False, "nullable": True},
            "ParameterParamScore": {"type": "float", "required": False, "nullable": True},
            "ParameterParamStatus": {"type": "string", "required": False, "nullable": True},
            "ParameterScale": {"type": "string", "required": False, "nullable": True},
            "ParameterSubParamStatus": {"type": "string", "required": False, "nullable": True},
            "ParameterDefinition": {"type": "string", "required": False, "nullable": True},
            "ParameterParamComments": {"type": "string", "required": False, "nullable": True},
            "CreateDateTime": {"type": "datetime", "required": False, "nullable": True},
            "ParameterEvaluationID": {"type": "int", "required": False, "nullable": True},
        },
        "required_fields": ["ParameterEvaluationCode"],
        "date_fields": ["CreateDateTime"],
        "numeric_fields": ["ParameterOrderID", "ParameterParamScore", "ParameterEvaluationID"]
    },
    
    "tbl_DW_EvaluationMaster": {
        "columns": {
            "ProcessCode": {"type": "string", "required": False, "nullable": True},
            "EvaluationAccuracy": {"type": "float", "required": False, "nullable": True},
            "FormName": {"type": "string", "required": False, "nullable": True},
            "SamplingName": {"type": "string", "required": False, "nullable": True},
            "EvaluationNo": {"type": "string", "required": False, "nullable": True},
            "ProcessGroupName": {"type": "string", "required": False, "nullable": True},
            "FormCode": {"type": "string", "required": False, "nullable": True},
            "TeamLeaderNumber": {"type": "string", "required": False, "nullable": True},
            "EvaluatorName": {"type": "string", "required": False, "nullable": True},
            "EvaluationQuality": {"type": "float", "required": False, "nullable": True},
            "CountryName": {"type": "string", "required": False, "nullable": True},
            "ClientScore": {"type": "float", "required": False, "nullable": True},
            "JobCode": {"type": "string", "required": False, "nullable": True},
            "EvaluationDateTime": {"type": "datetime", "required": False, "nullable": True},
            "TeamLeaderLocation": {"type": "string", "required": False, "nullable": True},
            "EvaluationID": {"type": "int", "required": False, "nullable": True},
            "FormTypeName": {"type": "string", "required": False, "nullable": True},
            "EvaluatorManagerNumber": {"type": "string", "required": False, "nullable": True},
            "EvaluationMappingCode": {"type": "string", "required": False, "nullable": True},
            "ProcessName": {"type": "string", "required": False, "nullable": True},
            "EvaluatorLocation": {"type": "string", "required": False, "nullable": True},
            "CoachingStatus": {"type": "string", "required": False, "nullable": True},
            "EvaluatorManagerName": {"type": "string", "required": False, "nullable": True},
            "EvaluatorManagerCode": {"type": "string", "required": False, "nullable": True},
            "EvaluatorManagerLocation": {"type": "string", "required": False, "nullable": True},
            "TeamLeaderCode": {"type": "string", "required": False, "nullable": True},
            "FormGroupName": {"type": "string", "required": False, "nullable": True},
            "FailCutOff": {"type": "float", "required": False, "nullable": True},
            "EvaluatorNumber": {"type": "string", "required": False, "nullable": True},
            "AssociateTeamName": {"type": "string", "required": False, "nullable": True},
            "SamplingCycleCode": {"type": "string", "required": False, "nullable": True},
            "SamplingEndDate": {"type": "datetime", "required": False, "nullable": True},
            "AssociateTeamCode": {"type": "string", "required": False, "nullable": True},
            "CreateDateTime": {"type": "datetime", "required": False, "nullable": True},
            "TeamManagerCode": {"type": "string", "required": False, "nullable": True},
            "EvaluationTypeCode": {"type": "string", "required": False, "nullable": True},
            "EvaluatorManagerLocationCode": {"type": "string", "required": False, "nullable": True},
            "AssociateLocationCode": {"type": "string", "required": False, "nullable": True},
            "SamplingStartDate": {"type": "datetime", "required": False, "nullable": True},
            "TeamLeaderName": {"type": "string", "required": False, "nullable": True},
            "AssociateNumber": {"type": "string", "required": False, "nullable": True},
            "AssociateLocation": {"type": "string", "required": False, "nullable": True},
            "TeamManagerName": {"type": "string", "required": False, "nullable": True},
            "TeamManagerLocation": {"type": "string", "required": False, "nullable": True},
            "TeamManagerNumber": {"type": "string", "required": False, "nullable": True},
            "AssociateName": {"type": "string", "required": False, "nullable": True},
        },
        "required_fields": [],
        "date_fields": ["EvaluationDateTime", "SamplingEndDate", "CreateDateTime", "SamplingStartDate"],
        "numeric_fields": ["EvaluationAccuracy", "EvaluationQuality", "ClientScore", "EvaluationID", "FailCutOff"]
    },
    
    "tbl_DW_EvaluationEntity": {
        "columns": {
            "EntityEvaluationCode": {"type": "string", "required": False, "nullable": True},
            "EntityName": {"type": "string", "required": False, "nullable": True},
            "EntityValue": {"type": "string", "required": False, "nullable": True},
            "EntityOrder": {"type": "int", "required": False, "nullable": True},
            "CreatedDateTime": {"type": "datetime", "required": False, "nullable": True},
            "EntityEvaluationID": {"type": "int", "required": False, "nullable": True},
            "ControlType": {"type": "string", "required": False, "nullable": True},
            "EntityEvaluationStatus": {"type": "string", "required": False, "nullable": True},
        },
        "required_fields": [],
        "date_fields": ["CreatedDateTime"],
        "numeric_fields": ["EntityOrder", "EntityEvaluationID"]
    },
    
    "tbl_DW_NRR": {
        "columns": {
            "rpt_month": {"type": "string", "required": False, "nullable": True},
            "rpt_quarter": {"type": "string", "required": False, "nullable": True},
            "rpt_week": {"type": "string", "required": False, "nullable": True},
            "email_queue_name": {"type": "string", "required": False, "nullable": True},
            "email_queue_language": {"type": "string", "required": False, "nullable": True},
            "region_name": {"type": "string", "required": False, "nullable": True},
            "site_name": {"type": "string", "required": False, "nullable": True},
            "case_atlas_level3": {"type": "string", "required": False, "nullable": True},
            "case_atlas_level4": {"type": "string", "required": False, "nullable": True},
            "secondary_sub_platform": {"type": "string", "required": False, "nullable": True},
            "org_name": {"type": "string", "required": False, "nullable": True},
            "poller_az_uid": {"type": "string", "required": False, "nullable": True},
            "associate_supervisor": {"type": "string", "required": False, "nullable": True},
            "associate_supervisor_manager_id": {"type": "string", "required": False, "nullable": True},
            "tenure": {"type": "string", "required": False, "nullable": True},
            "case_channel": {"type": "string", "required": False, "nullable": True},
            "Primary_Q_HMD_Poll_Volume": {"type": "int", "required": False, "nullable": True},
            "Primary_Q_HMD_Y": {"type": "int", "required": False, "nullable": True},
            "Primary_Q_HMD_N": {"type": "int", "required": False, "nullable": True},
            "HMD_Type_Redistribution_Reason": {"type": "string", "required": False, "nullable": True},
            "EMP_ID": {"type": "string", "required": False, "nullable": True},
            "EMP_Name": {"type": "string", "required": False, "nullable": True},
            "TM_ID": {"type": "string", "required": False, "nullable": True},
            "TM_Name": {"type": "string", "required": False, "nullable": True},
        },
        "required_fields": [],
        "date_fields": [],
        "numeric_fields": ["Primary_Q_HMD_Poll_Volume", "Primary_Q_HMD_Y", "Primary_Q_HMD_N"]
    },
    
    "tbl_DW_ARR": {
        "columns": {
            "Year": {"type": "int", "required": False, "nullable": True},
            "Week": {"type": "string", "required": False, "nullable": True},
            "Channel": {"type": "string", "required": False, "nullable": True},
            "Associate_Login": {"type": "string", "required": False, "nullable": True},
            "EMP_ID": {"type": "string", "required": False, "nullable": True},
            "EMP_Name": {"type": "string", "required": False, "nullable": True},
            "Supervisor_Id": {"type": "string", "required": False, "nullable": True},
            "TM_EMP_ID": {"type": "string", "required": False, "nullable": True},
            "TM_Name": {"type": "string", "required": False, "nullable": True},
            "Language": {"type": "string", "required": False, "nullable": True},
            "Secondary_Sub_Platform": {"type": "string", "required": False, "nullable": True},
            "WA_Handled": {"type": "int", "required": False, "nullable": True},
            "WI_Handled": {"type": "int", "required": False, "nullable": True},
            "WA_PAA": {"type": "int", "required": False, "nullable": True},
            "WA_PMA": {"type": "int", "required": False, "nullable": True},
            "WA_Resolved": {"type": "int", "required": False, "nullable": True},
            "WA_Reopened": {"type": "int", "required": False, "nullable": True},
            "WA_Transferred": {"type": "int", "required": False, "nullable": True},
            "WA_Othered": {"type": "int", "required": False, "nullable": True},
            "WA_Dropped": {"type": "int", "required": False, "nullable": True},
            "WA_Consult": {"type": "int", "required": False, "nullable": True},
            "Month": {"type": "string", "required": False, "nullable": True},
            "Ranking": {"type": "int", "required": False, "nullable": True},
            "Month_UID": {"type": "string", "required": False, "nullable": True},
            "LOB": {"type": "string", "required": False, "nullable": True},
        },
        "required_fields": [],
        "date_fields": [],
        "numeric_fields": ["Year", "WA_Handled", "WI_Handled", "WA_PAA", "WA_PMA", "WA_Resolved", "WA_Reopened", "WA_Transferred", "WA_Othered", "WA_Dropped", "WA_Consult", "Ranking"]
    }
}


def get_schema_for_file(filename: str, config: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """Get schema definition for a file based on filename pattern or config rules"""
    return get_schema_for_file_with_config(filename, config)


def get_schema_for_file_with_config(filename: str, config: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
    """Get schema definition for a file based on config-driven rules with fallback patterns"""
    filename_lower = filename.lower()

    # Config-driven rules (preferred for production)
    # Expected shape:
    # schema_detection:
    #   rules:
    #     - table_name: tbl_DW_ARR
    #       filename_contains: ["tbl_dw_arr", "arr"]
    if config:
        schema_detection = config.get("schema_detection", {}) if isinstance(config, dict) else {}
        rules = schema_detection.get("rules", []) if isinstance(schema_detection, dict) else []
        for rule in rules:
            if not isinstance(rule, dict):
                continue

            table_name = rule.get("table_name")
            if not table_name or table_name not in SCHEMA_REGISTRY:
                continue

            contains = rule.get("filename_contains", [])
            if isinstance(contains, str):
                contains = [contains]

            for needle in contains:
                if needle and str(needle).lower() in filename_lower:
                    schema = SCHEMA_REGISTRY[table_name]
                    return {"table_name": table_name, **schema}
    
    # Define flexible matching patterns for different table name variations
    pattern_mappings = {
        "tbl_DW_EvaluationParameter": ["tbl_dw_evaluationparameter", "table_dw_evaluationparameter", "evaluationparameter"],
        "tbl_DW_EvaluationMaster": ["tbl_dw_evaluationmaster", "table_dw_evaluationmaster", "evaluationmaster"],
        "tbl_DW_EvaluationEntity": ["tbl_dw_evaluationentity", "table_dw_evaluationentity", "evaluationentity"],
        "tbl_DW_NRR": ["tbl_dw_nrr", "table_dw_nrr", "nrr"],
        "tbl_DW_ARR": ["tbl_dw_arr", "table_dw_arr", "arr"]
    }
    
    # First try exact matches
    for table_name, schema in SCHEMA_REGISTRY.items():
        if table_name.lower() in filename_lower:
            return {"table_name": table_name, **schema}
    
    # Then try flexible pattern matching
    for table_name, patterns in pattern_mappings.items():
        for pattern in patterns:
            if pattern in filename_lower:
                schema = SCHEMA_REGISTRY[table_name]
                return {"table_name": table_name, **schema}
    
    # Return default schema if no match
    return None


def get_date_fields(filename: str, config: Optional[Dict[str, Any]] = None) -> List[str]:
    """Get date fields for a file"""
    schema = get_schema_for_file(filename, config)
    return schema.get("date_fields", []) if schema else []


def get_numeric_fields(filename: str, config: Optional[Dict[str, Any]] = None) -> List[str]:
    """Get numeric fields for a file"""
    schema = get_schema_for_file(filename, config)
    return schema.get("numeric_fields", []) if schema else []


def get_required_fields(filename: str, config: Optional[Dict[str, Any]] = None) -> List[str]:
    """Get required fields for a file"""
    schema = get_schema_for_file(filename, config)
    return schema.get("required_fields", []) if schema else []
