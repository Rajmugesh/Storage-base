"""Email notification with detailed processing reports"""

import logging
import smtplib
from email.message import EmailMessage
from typing import Dict, List, Any
from datetime import datetime

logger = logging.getLogger(__name__)


class Notifier:
    """Send processing reports via email"""
    
    def __init__(self, config: Dict):
        self.enabled = config.get("notify", False)
        self.email_config = config.get("email", {})
    
    def send_report(self, reports: List, stats: Dict[str, Any]) -> bool:
        """Send detailed processing report via email"""
        if not self.enabled:
            logger.info("Notifications disabled")
            return False
        
        # Check if email is configured
        required = ['host', 'port', 'username', 'password', 'from', 'to']
        missing = [k for k in required if not self.email_config.get(k)]
        if missing:
            logger.warning(f"Email not configured (missing: {missing})")
            return False
        
        try:
            # Build email content
            subject = f"Data Pipeline Report - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            body = self._build_report_body(reports, stats)
            
            msg = EmailMessage()
            msg["Subject"] = subject
            msg["From"] = self.email_config["from"]
            msg["To"] = self.email_config["to"]
            msg.set_content(body)
            
            # Send email
            with smtplib.SMTP(self.email_config["host"], int(self.email_config["port"]), timeout=10) as server:
                server.starttls()
                server.login(self.email_config["username"], self.email_config["password"])
                server.send_message(msg)
            
            logger.info("Report email sent successfully")
            return True
            
        except Exception as e:
            logger.exception(f"[NOTIFY] Email notification failed :: {type(e).__name__}: {e}")
            return False
    
    def _build_report_body(self, reports: List, stats: Dict[str, Any]) -> str:
        """Build detailed report body"""
        lines = [
            "=" * 60,
            "DATA INGESTION PIPELINE REPORT",
            "=" * 60,
            f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Status: {stats.get('status', 'UNKNOWN')}",
            f"Processing Time: {stats.get('processing_time', 0):.2f} seconds",
            "",
            "SUMMARY",
            "-" * 40,
            f"Files Processed: {stats.get('files_processed', 0)}",
            f"Total Input Rows: {stats.get('total_input_rows', 0):,}",
            f"Total Output Rows: {stats.get('total_output_rows', 0):,}",
            f"Data Retention: {stats.get('retention_rate', 0):.1%}",
            "",
            "FILE DETAILS",
            "-" * 40
        ]
        
        # Add each file's report
        for report in reports:
            lines.append(report.summary())
            lines.append("")
        
        lines.extend([
            "=" * 60,
            "End of Report",
            "=" * 60
        ])
        
        return "\n".join(lines)
