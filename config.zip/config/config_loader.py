import yaml
import os
import re
from typing import Any, Dict
import pathlib

def load_config(config_file: str = str(pathlib.Path(__file__).parent / "config.yaml")) -> Dict[str, Any]:
    """Load configuration with environment variable substitution"""
    try:
        with open(config_file, "r") as file:
            config_content = file.read()
        
        # Substitute environment variables
        config_content = _substitute_env_vars(config_content)
        
        # Parse YAML
        config = yaml.safe_load(config_content)
        
        # Validate required configuration
        _validate_config(config)
        
        return config
        
    except FileNotFoundError:
        raise FileNotFoundError(f"Configuration file not found: {config_file}")
    except yaml.YAMLError as e:
        raise ValueError(f"Error parsing YAML configuration: {e}")
    except Exception as e:
        raise RuntimeError(f"Error loading configuration: {e}")

def _substitute_env_vars(content: str) -> str:
    """Substitute environment variables in format ${VAR_NAME} with optional defaults"""
    def replace_var(match):
        var_name = match.group(1)
        default_value = match.group(2) if len(match.groups()) > 1 else None
        
        # Get environment variable
        env_value = os.getenv(var_name)
        
        if env_value is not None:
            return env_value
        elif default_value is not None:
            return default_value
        else:
            # For sensitive values, use placeholder instead of raising error
            if any(sensitive in var_name.lower() for sensitive in ['password', 'key', 'secret', 'token']):
                return "PLACEHOLDER_VALUE"
            return f"${{{var_name}}}"  # Keep placeholder if no default
    
    # Pattern to match ${VAR_NAME} or ${VAR_NAME:default_value}
    pattern = r'\$\{([^}:]+)(?::([^}]*))?\}'
    return re.sub(pattern, replace_var, content)

def _validate_config(config: Dict[str, Any]) -> None:
    """Validate configuration structure and required fields"""
    required_sections = ["paths"]
    required_paths = ["raw", "output", "logs"]
    
    # Check required sections
    for section in required_sections:
        if section not in config:
            raise ValueError(f"Missing required configuration section: {section}")
    
    # Check required paths
    for path_key in required_paths:
        if path_key not in config["paths"]:
            raise ValueError(f"Missing required path configuration: paths.{path_key}")
    
    # Validate processing configuration
    if "processing" in config:
        processing = config["processing"]
        if "batch_size" in processing and not isinstance(processing["batch_size"], int):
            raise ValueError("processing.batch_size must be an integer")
        if "max_workers" in processing and not isinstance(processing["max_workers"], int):
            raise ValueError("processing.max_workers must be an integer")
    
    # Validate data quality configuration
    if "data_quality" in config:
        dq = config["data_quality"]
        if "duplicate_strategy" in dq:
            valid_strategies = ["keep_first", "keep_last", "remove_all"]
            if dq["duplicate_strategy"] not in valid_strategies:
                raise ValueError(f"Invalid duplicate_strategy. Must be one of: {valid_strategies}")
    
    # Validate email configuration if notifications are enabled
    if config.get("notify", False) and "email" in config:
        email_config = config["email"]
        required_email_fields = ["host", "port"]
        
        for field in required_email_fields:
            if field not in email_config:
                raise ValueError(f"Missing required email configuration: email.{field}")
