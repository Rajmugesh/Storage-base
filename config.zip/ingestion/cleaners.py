"""
Data Cleaning Pipeline

Implements:
- Data cleaning rules
- Remove empty rows and columns
- Normalize date formats
- Standardize text fields (trim, lowercase where needed)
- Handle missing values appropriately
- Remove duplicates
- Transform data to match database schema
- Create cleaned data output
"""

import pandas as pd
import numpy as np
import logging
import re
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)

# Date patterns for auto-detection
DATE_PATTERNS = [r'.*date.*', r'.*time.*', r'.*created.*', r'.*modified.*', r'.*updated.*']


class CleaningReport:
    """Report for cleaning operations"""
    __slots__ = ['file_name', 'input_rows', 'output_rows', 'empty_rows_removed',
                 'empty_cols_removed', 'duplicates_removed', 'transformations', 'processing_time']
    
    def __init__(self, file_name: str):
        self.file_name = file_name
        self.input_rows = 0
        self.output_rows = 0
        self.empty_rows_removed = 0
        self.empty_cols_removed = []
        self.duplicates_removed = 0
        self.transformations = []
        self.processing_time = 0.0
    
    def summary(self) -> str:
        lines = [
            f"Cleaning Report: {self.file_name}",
            f"  Input rows: {self.input_rows:,}",
            f"  Output rows: {self.output_rows:,}",
            f"  Empty rows removed: {self.empty_rows_removed:,}",
            f"  Duplicates removed: {self.duplicates_removed:,}",
            f"  Processing time: {self.processing_time:.2f}s"
        ]
        if self.empty_cols_removed:
            lines.append(f"  Empty columns removed: {', '.join(self.empty_cols_removed)}")
        if self.transformations:
            lines.append(f"  Transformations: {len(self.transformations)}")
        return "\n".join(lines)


class DataCleaner:
    """
    Data Cleaning Pipeline
    
    Applies cleaning rules to transform raw data into clean, standardized output.
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        dq = config.get("data_quality", {})
        
        self.null_values = set(dq.get("null_values", ['', 'NULL', 'null', 'None', 'N/A', 'n/a', 'nan', 'NaN']))
        self.numeric_fill = dq.get("numeric_fill_value", 0)
        self.date_format = dq.get("date_format", "%Y-%m-%d %H:%M:%S")
        self.duplicate_strategy = dq.get("duplicate_strategy", "keep_first")
        
        self.output_path = Path(config["paths"]["output"])
        self.output_path.mkdir(exist_ok=True)

    def clean_dataframe(self, df: pd.DataFrame, filename: str) -> Tuple[pd.DataFrame, CleaningReport]:
        """
        Apply all cleaning rules to a dataframe.
        
        Cleaning steps:
        1. Remove empty rows
        2. Remove empty columns
        3. Normalize date formats (duplicates already handled in validation)
        4. Standardize text fields
        5. Handle missing values
        6. Transform to database schema
        """
        start = datetime.now()
        report = CleaningReport(filename)
        report.input_rows = len(df)
        
        # Step 1: Remove completely empty rows
        df, empty_rows = self._remove_empty_rows(df)
        report.empty_rows_removed = empty_rows
        
        # Step 2: Remove completely empty columns
        df, empty_cols = self._remove_empty_columns(df)
        report.empty_cols_removed = empty_cols
        
        # Step 3: Remove duplicates - DISABLED (already handled in validation step)
        report.duplicates_removed = 0
        
        # Step 4: Normalize date formats
        df, date_transforms = self._normalize_dates(df)
        report.transformations.extend(date_transforms)
        
        # Step 5: Standardize text fields
        df, text_transforms = self._standardize_text_fields(df)
        report.transformations.extend(text_transforms)
        
        # Step 6: Handle missing values
        df, missing_transforms = self._handle_missing_values(df)
        report.transformations.extend(missing_transforms)
        
        # Step 7: Transform to database schema (column naming, ordering)
        df = self._transform_to_schema(df, filename)
        
        report.output_rows = len(df)
        report.processing_time = (datetime.now() - start).total_seconds()
        
        return df, report

    def _remove_empty_rows(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, int]:
        """Remove rows that are completely empty"""
        before = len(df)
        df = df.dropna(how='all')
        removed = before - len(df)
        if removed > 0:
            logger.debug(f"Removed {removed} empty rows")
        return df, removed

    def _remove_empty_columns(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
        """Remove columns that are completely empty"""
        # Check for null and null-like values
        null_mask = df.isna() | df.isin(self.null_values)
        empty_cols = df.columns[null_mask.all()].tolist()
        
        if empty_cols:
            df = df.drop(columns=empty_cols)
            logger.debug(f"Removed empty columns: {empty_cols}")
        
        return df, empty_cols

    def _remove_duplicates(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, int]:
        """Remove duplicate rows"""
        before = len(df)
        keep = 'first' if self.duplicate_strategy == 'keep_first' else 'last'
        df = df.drop_duplicates(keep=keep)
        removed = before - len(df)
        if removed > 0:
            logger.debug(f"Removed {removed} duplicate rows")
        return df, removed

    def _normalize_dates(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
        """Normalize all date columns to standard format"""
        transforms = []
        
        for col in df.columns:
            if any(re.match(p, col.lower()) for p in DATE_PATTERNS):
                try:
                    original_nulls = df[col].isna().sum()
                    df[col] = pd.to_datetime(df[col], errors='coerce', format='mixed')
                    df[col] = df[col].dt.strftime(self.date_format)
                    df[col] = df[col].replace('NaT', np.nan)
                    transforms.append(f"Normalized date: {col}")
                    logger.debug(f"Normalized date column: {col}")
                except Exception as e:
                    logger.warning(f"Failed to normalize date column {col}: {e}")
        
        return df, transforms

    def _standardize_text_fields(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
        """Standardize text fields: trim whitespace"""
        transforms = []
        
        for col in df.select_dtypes(include=['object']).columns:
            # Skip date-like columns
            if any(re.match(p, col.lower()) for p in DATE_PATTERNS):
                continue
            
            # Trim whitespace
            df[col] = df[col].astype(str).str.strip()
            
            # Replace null-like strings with NaN
            df[col] = df[col].replace(list(self.null_values), np.nan)
            df[col] = df[col].replace(['nan', 'None'], np.nan)
            
            transforms.append(f"Standardized text: {col}")
        
        return df, transforms

    def _handle_missing_values(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, List[str]]:
        """
        Handle missing values appropriately:
        - Numeric columns: fill with 0
        - Categorical columns: keep as null
        """
        transforms = []
        
        for col in df.columns:
            # Skip date columns
            if any(re.match(p, col.lower()) for p in DATE_PATTERNS):
                continue
            
            # Replace null-like strings
            df[col] = df[col].replace(list(self.null_values), np.nan)
            
            # Determine if numeric
            numeric = pd.to_numeric(df[col], errors='coerce')
            non_null = df[col].notna().sum()
            numeric_count = numeric.notna().sum()
            
            if non_null > 0 and (numeric_count / non_null) > 0.5:
                # Numeric column: fill with configured value
                null_count = numeric.isna().sum()
                df[col] = numeric.fillna(self.numeric_fill)
                if null_count > 0:
                    transforms.append(f"Filled {null_count} nulls in numeric column: {col}")
            else:
                # Categorical: ensure clean null representation
                if df[col].dtype == 'object':
                    df[col] = df[col].replace(['nan', 'None', ''], np.nan)
        
        return df, transforms

    def _transform_to_schema(self, df: pd.DataFrame, filename: str) -> pd.DataFrame:
        """
        Transform data to match database schema.
        - Standardize column names (remove special characters)
        - Ensure consistent data types
        """
        # Handle empty DataFrames
        if df.empty or len(df.columns) == 0:
            return df
        
        # Clean column names (remove leading/trailing spaces)
        try:
            df.columns = df.columns.str.strip()
        except AttributeError:
            # Handle case where columns are not strings (e.g., empty DataFrame)
            df.columns = [str(col).strip() for col in df.columns]
        
        return df

    def process_files(self, files: Dict[str, pd.DataFrame]) -> Tuple[Dict[str, pd.DataFrame], List[CleaningReport]]:
        """Process multiple files through the cleaning pipeline"""
        cleaned_files = {}
        reports = []
        
        for filename, df in files.items():
            logger.info(f"Cleaning {filename} ({len(df):,} rows)")
            
            cleaned_df, report = self.clean_dataframe(df, filename)
            cleaned_files[filename] = cleaned_df
            reports.append(report)
            
            logger.info(report.summary())
        
        return cleaned_files, reports
