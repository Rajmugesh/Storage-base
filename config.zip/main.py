#!/usr/bin/env python3
"""Production Data Ingestion Pipeline - CSV & Excel Support"""

import sys
import logging
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from src.orchestrator import PipelineOrchestrator
from config.config_loader import load_config


def setup_logging(config):
    """Configure logging to file and console"""
    logs_path = Path(config["paths"]["logs"])
    logs_path.mkdir(exist_ok=True)
    
    log_file = logs_path / f"pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
    
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ],
        force=True
    )
    logging.getLogger('pandas').setLevel(logging.WARNING)
    return log_file


def main():
    """Main entry point"""
    try:
        config = load_config()
        log_file = setup_logging(config)
        
        logger = logging.getLogger(__name__)
        logger.info(f"Log file: {log_file}")
        
        stats = PipelineOrchestrator(config).run()
        
        if stats['status'] == 'COMPLETED':
            if stats['files_processed'] > 0:
                logger.info(f"SUCCESS: {stats['total_output_rows']:,} rows processed in {stats['processing_time']:.2f}s")
            return 0
        else:
            logger.error(f"FAILED: {stats.get('errors', [])}")
            return 1
            
    except Exception as e:
        logging.exception("Unhandled exception in pipeline execution")
        return 1


if __name__ == "__main__":
    # Ensure we're using the correct module path
    import os
    os.chdir(Path(__file__).parent)
    sys.exit(main())
